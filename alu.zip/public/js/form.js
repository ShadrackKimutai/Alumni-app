function handleEdit() {
	document.getElementById('fullname').disabled = false;
	document.getElementById('idnum').disabled = false;
	document.getElementById('adm'.disabled = false; 
	document.getElementById('mobile'.disabled = false; 
	document.getElementById('email'.disabled = false;
	document.getElementById('dept'.disabled = false;
	document.getElementById('course'.disabled = false; 
	document.getElementById('level'.disabled = false;
	document.getElementById('current_address'.disabled = false;  
	document.getElementById('permanent_address'.disabled = false;
	document.getElementById('occupation'.disabled = false; 
	document.getElementById('occupation_place'.disabled = false; 
	document.getElementById('nextofkin'.disabled = false;
	document.getElementById('nextofkinadd'.disabled = false;
	document.getElementById('nextofkinphone'.disabled = false; 
	document.getElementById('placeofworkadd'.disabled = false; 
	document.getElementById('supervisoradd'.disabled = false; 
	document.getElementById('edit').hidden = true;
	document.getElementById('save').hidden = false;

  return false;
}