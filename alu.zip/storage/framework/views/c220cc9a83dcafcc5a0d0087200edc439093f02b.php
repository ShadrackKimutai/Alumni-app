<?php $__env->startSection('title'); ?>
 <title>Update Alumni</title>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container"> 
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header"><?php echo e(__('Update Your Details')); ?></div>

        <div class="card-body">


          
<br />

  
      <form method="post" action="<?php echo e(route('alumnis.update', $alumni->id)); ?>">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="name">Name:</label>
          <input type="text" class="form-control" name="fullname" value="<?php echo e($alumni->fullname); ?>" />
        </div>
        <div class="form-group">
          <label for="dept">dept:</label>
          <input type="text" class="form-control" name="dept" value="<?php echo e($alumni->dept); ?>" />
        </div>
        <div class="form-group">
          <label for="course">course:</label>
          <input type="text" class="form-control" name="course" value="<?php echo e($alumni->course); ?>" />
        </div>
         <div class="form-group">
          <label for="feser">Final Exam Series:</label>
          <input type="text" class="form-control" name="feser" value="<?php echo e($alumni->feser); ?>" />
        </div>
        <div class="form-group">
          <label for="feyear">Final Year:</label>
          <input type="text" class="form-control" name="feyear" value="<?php echo e($alumni->feyear); ?>" />
        </div>
        <div class="form-group">
          <label for="idnum">ID Number :</label>
          <input type="text" class="form-control" name="idnum" value="<?php echo e($alumni->idnum); ?>" />
        </div>
         <div class="form-group">
          <label for="adm">Student Registration Number :</label>
          <input type="text" class="form-control" name="adm" value="<?php echo e($alumni->adm); ?>" />
        </div>
         <div class="form-group">
          <label for="level">Level :</label>
          <input type="text" class="form-control" name="level" value="<?php echo e($alumni->level); ?>" />
        </div>
        <div class="form-group">
          <label for="current_address">Your Current Address:</label>
          <input type="text" class="form-control" name="current_address" value="<?php echo e($alumni->current_address); ?>" />
        </div>
         <div class="form-group">
          <label for="permanent_address">Your Permanent Address:</label>
          <input type="text" class="form-control" name="permanent_address" value="<?php echo e($alumni->permanent_address); ?>" />
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input type="email" class="form-control" name="email" value="<?php echo e($alumni->email); ?>" />
        </div>
        <div class="form-group">
          <label for="mobile">Mobile :</label>
          <input type="text" class="form-control" name="mobile" value="<?php echo e($alumni->mobile); ?>" />
        </div>
        <div class="form-group">
          <label for="nextofkin">Next of Kin:</label>
          <input type="text" class="form-control" name="nextofkin" value="<?php echo e($alumni->nextofkin); ?>" />
        </div>
         <div class="form-group">
          <label for="nextofkinphone">Next of Kin Mobile :</label>
          <input type="text" class="form-control" name="nextofkinphone" value="<?php echo e($alumni->nextofkinphone); ?>" />
        </div>
        <div class="form-group">
          <label for="nextofkinadd">Next of Kin Address:</label>
          <input type="text" class="form-control" name="nextofkinadd" value="<?php echo e($alumni->nextofkinadd); ?>" />
        </div>
         <div class="form-group">
          <label for="occupation">Current Job:</label>
          <input type="text" class="form-control" name="occupation" value="<?php echo e($alumni->occupation); ?>" />
        </div>
        <div class="form-group">
          <label for="placeofworkadd">Place of Work Address:</label>
          <input type="text" class="form-control" name="placeofworkadd" value="<?php echo e($alumni->placeofworkadd); ?>" />
        </div>

        <div class="form-group">
          <label for="occupation_place">Place of Work :</label>
          <input type="text" class="form-control" name="occupation_place" value="<?php echo e($alumni->occupation_place); ?>" />
        </div>

        <div class="form-group">
          <label for="supervisoradd">Work Supervisors phone:</label>
          <input type="text" class="form-control" name="supervisoradd" value="<?php echo e($alumni->supervisoradd); ?>" />
        </div>
          <Button type="submit" name="previous" class="btn btn-primary">Update</Button>

      </form>
       </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /shared/httpd/alumni/alumni/resources/views/alumni/edit.blade.php ENDPATH**/ ?>