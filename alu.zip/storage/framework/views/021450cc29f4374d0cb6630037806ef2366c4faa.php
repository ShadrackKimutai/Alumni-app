<?php $__env->startSection('content'); ?>



<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-14">
      <div class="card">
        <div class="card-header"><?php echo e(__('Registered Alumni')); ?></div>

        <div class="card-body">


          <div class="col-md-4" >
            <form action="/search" method="get">
              <?php echo csrf_field(); ?>
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search this " name="search">
                <div class="input-group-append">
                  <button class="btn btn-secondary" type="submit"><i class="fa fa-search"></i></button>
                </div>
              </div>
            </form> 



          </div>
<br />

     <?php echo e($alumni->links()); ?>

          <table class="table table-bordered">
            <thead>
              <th>Reg Number</th>
              <th>Full Name</th>
              <th>ID/Passport</th>
              <th>Course</th>
              <th>Department</th>
              <th>Mobile</th>
              <th>EMail</th>
            </thead>
            <tbody>
              <?php $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
              <tr>
                
                <td><?php echo e($alumn->Adm); ?> </td>
                <td><?php echo e($alumn->fullname); ?> </td>
                <td><?php echo e($alumn->IDNum); ?> </td>
                <td><?php echo e($alumn->course); ?> </td>
                <td><?php echo e($alumn->dept); ?> </td>
                <th><?php echo e($alumn->mobile); ?></th>
                <td><?php echo e($alumn->email); ?></td>
                <td>
                    <a href="#" class="btn btn-primary">Edit</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($alumni->links()); ?>

        </div>
      </div>
    </div>
  </div>
</div>
    <!-- End Multi step form -->   
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /shared/httpd/alumni/alumni/resources/views/home.blade.php ENDPATH**/ ?>