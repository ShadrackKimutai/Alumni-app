<?php $__env->startSection('title'); ?>
 <title>Registering New Alumni</title>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- Navigation -->


<!-- multistep form -->


  <h4 class="text-black"><strong>Register as Alumni</strong></h2>


      <form id="msform" name="frmRegistration" method="post" action="<?php echo e(route('alumnis.store')); ?>">
        <?php echo csrf_field(); ?> 

        <br> <ul id="progressbar" type="">
          <li class="active"><i class="fa fa-user fa-4x"></i></li>
          <li><i class="fa fa-industry  fa-4x"></i></li>
          <li><i class="fa fa-university fa-4x"></i></li>
        </ul>
        <fieldset>
        
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
          <h3>Following Required Items were Missing in your form. Correct To Proceed</h3>
            <ul style="list-style-type: square;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div><br />
        <?php else: ?>
            <h2 class="fs-title">Enter the details requested.</h2>
            <h3 class="fs-subtitle">If information is not applicable use N/A</h3>
        <?php endif; ?>
          <label class="text-black text-left" for="admissionnumber">Your Student Registration Number</label>
          <input type="text" class="form-control" id="inputAdmissionnumber" name ="adm" value="<?php echo e(old('adm')); ?>" placeholder="e.g. 117R0008">
          <label class="text-black text-left" for="inputEmail">Enter Full Names</label>
          <input type="text" class="form-control" name="fullname" id="inputName" placeholder="e.g. Miss. Jane Doe" value="<?php echo e(old('fullname')); ?>">


          <label class="text-black text-left" for="inputEmail">Enter National ID/Passport Number</label>
          <input type="text" class="form-control" name="idnum" id="inputID" placeholder="e.g. 21436587" value="<?php echo e(old('idnum')); ?>">


          <label class="text-black text-left" for="no">Current Mobile Phone Number</label>
          <input type="text" class="form-control" name="mobile" id="inputphone" placeholder="e.g. 0734567890" value="<?php echo e(old('mobile')); ?>">

           <label class="text-black text-left" for="phoneno">Alternative Mobile Phone Number</label>
          <input type="text" class="form-control" name="altphone" id="altphone" placeholder="e.g. 0734567890" value="<?php echo e(old('altphone')); ?>">

          <label class="text-black text-left" for="inputEmail">Enter email Address</label>
          <input type="email" class="form-control" name="email" id="inputName" placeholder="e.g. janedoe@yahoo.com " value="<?php echo e(old('email')); ?>">

          <label class="text-black text-left" for="inputEmail">Enter Current Address</label>
          <input type="text" class="form-control" name="current_address" id="inputName" placeholder="e.g. P.O. Box 123456789 -00200- Nairobi " value="<?php echo e(old('current_address')); ?>">

          <label class="text-black text-left" for="inputEmail">Enter Permanent Address (can be similar to the above) </label>
          <input type="text" class="form-control" name="permanent_address" id="inputName" placeholder="e.g. P.O. Box 123456 -30108- Timboroa " value="<?php echo e(old('permanent_address')); ?>">
          <label class="text-black text-left" for="admissionnumber">Next of Kin</label>
          <input type="text" class="form-control" id="nextofkin" name ="nextofkin" placeholder="e.g. Jane Doe" value="<?php echo e(old('adm')); ?>">
          <label class="text-black text-left" for="admissionnumber">Next of Kin Address</label>
          <input type="text" class="form-control" id="nextofkinadd" name ="nextofkinadd" placeholder="e.g. P.O. Box 234 -00100- Nairobi" value="<?php echo e(old('nextofkinadd')); ?>">
          <label class="text-black text-left" for="admissionnumber">Next of Kin Mobile Phone</label>
          <input type="text" class="form-control" id="nextofkinphone" name ="nextofkinphone" placeholder="e.g. 0734567890" value="<?php echo e(old('nextofkinphone')); ?>">

          <input type="button" name="next" class="next action-button " value="Next" />
        
        </fieldset>  
        <fieldset>
          <h2 class="fs-title">Employment Details</h2>
          <h3 class="fs-subtitle">Give brief description about your current employment. If Unemployed use N/A in each</h3>
          <label class="text-black text-left" for="admissionnumber">Current Occupation (if None use N/A) </label>
          <input type="text" class="form-control" id="inputAdmissionnumber" name ="occupation" placeholder="e.g. Network Administrator" value="<?php echo e(old('occupation')); ?>">

          <label class="text-black text-left" for="admissionnumber">Place of Current Occupation ( if None use N/A)</label>
          <input type="text" class="form-control" id="inputAdmissionnumber" name ="occupation_place" placeholder="e.g. Nairobi" value="<?php echo e(old('occupation_place')); ?>">

          <label class="text-black text-left" for="inputsupname">Supervisor Telephone Number ( if None use N/A)</label>
          <input type="text" class="form-control" name="supervisoradd" id="supphone" placeholder="e.g. 0734567890" value="<?php echo e(old('supervisoradd')); ?>">
          <label class="text-black text-left" for="inputsupname">Address of Current Place of Work ( if None use N/A)</label>
          <input type="text" class="form-control" name="placeofworkadd" id="occuadd" value="<?php echo e(old('placeofworkadd')); ?>" placeholder="e.g. Rift Valley Technical Training Institute, P.O. Box 244 -30100-,Eldoret">

          <input type="button" name="previous" class="previous action-button" value="Previous" />
         <input type="button" name="next" class="next action-button" value="Next" />
        
        </fieldset> 


        <fieldset>
          <h2 class="fs-title">Academic Details</h2>
          <h3 class="fs-subtitle">State the course you just completed</h3>

          <label class="text-black text-left" for="department">Select your Course's Department</label>
          <select class="form-control" id="dept" name="dept">

           <option>Automotive Engineering</option>
           <option>Building & Civil Engineering</option>
           <option>Business and Development Studies</option>
           <option>Electrical & Electronic Engineering</option>
           <option>Hospitality & Dietetics Management</option>
           <option>Information Communication Technology</option>
           <option>Mechanical and Automotive Engineering</option>
           <option>Pharmacy & Chemical Science</option>
           <option>Medical & Biological Sciences</option>

         </select>
         <label class="text-black text-left" for="admissionnumber">Course (in full as per registration)</label>
         <input type="text" class="form-control" id="inputcourse" value="<?php echo e(old('course')); ?>" name="course" placeholder="e.g. Diploma in Information Communication Technology">
         <label class="text-black text-left" for="courselevel">Select your current Course's Level</label>
         <select class="form-control" id="select" name="level">

           <option>Artisan</option>
           <option>Craft</option>
           <option>Diploma</option>
           <option>Higher Diploma</option>


         </select>
         <label class="text-black text-left" for="year"> Final Examination Year</label>
         <input type="number" class="form-control" id="datepicker" name="feyear" placeholder="2019" min="1982" max="2019" value="2019">
         <label class="text-black text-left" for="year"> Series</label>
         <Select class="form-control" id="selectSeries" name="feser">
          <option>July</option>
          <option>November</option>
        </Select>
      <input type="button" name="previous" class="previous action-button" value="Previous" />
          <input type="submit" name="previous" class="submit-button" value="Save" />
         
      </fieldset> 
    </form> 


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rvtiacke/public_html/alumni/resources/views/alumni/create.blade.php ENDPATH**/ ?>