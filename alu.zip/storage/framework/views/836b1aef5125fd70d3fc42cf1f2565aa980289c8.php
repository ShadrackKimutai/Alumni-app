<?php $__env->startSection('content'); ?>
  <!-- Navigation -->
  <main>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="/">Home</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        Menu
        <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
        
        </ul>
      </div>
    </div>
  </nav>

 

  <section class="download bg-secondary">
      <div class="container">
      <div class="row">
        <div class="col-md-8 mx-auto">
          <h2 class="section-heading text-white"><strong>Register as Alumni</strong></h2>
         
        
     <form name="frmRegistration" method="post" action="maindetails.php">
  <br> <p class="text-white">Fill this form if you have not yet Registered as alumni</p>   
        <div class="form-group">
            <label class="text-white" for="inputEmail">Enter Full Names</label>
            <input type="text" class="form-control" name="fullname" id="inputName" placeholder="e.g. Miss. Jane Doe">
        </div>
    <div class="form-group">
      <label class="text-white" for="inputEmail">Enter National ID/Passport Number</label>
            <input type="text" class="form-control" name="idnum" id="inputID" placeholder="e.g. 21436587">
    </div>
    <div class="form-group">
      <label class="text-white" for="no">Current Mobile Phone Number</label>
            <input type="text" class="form-control" name="mobile" id="inputphone" placeholder="e.g. 0734567890">
    </div>
    <div class="form-group">
      <label class="text-white" for="otherno">Other Mobile Phone Number</label>
            <input type="text" class="form-control" name="altmobile" id="altmobile" placeholder="e.g. 0734567890">
    </div>
    <div class="form-group">
      <label class="text-white" for="inputEmail">Enter email Address</label>
            <input type="email" class="form-control" name="email" id="inputName" placeholder="e.g. janedoe@yahoo.com ">
    </div>
    <div class="form-group">
      <label class="text-white" for="inputEmail">Enter Current Address</label>
            <input type="text" class="form-control" name="caddress" id="inputName" placeholder="e.g. P.O. Box 123456789 -00200- Nairobi ">
    </div>
    <div class="form-group">
      <label class="text-white" for="inputEmail">Enter Permanent Address (can be similar to the above) </label>
            <input type="text" class="form-control" name="paddress" id="inputName" placeholder="e.g. P.O. Box 123456 -30108- Timboroa ">
    </div>
     <div class="form-group">
            <label class="text-white" for="admissionnumber">Next of Kin</label>
            <input type="text" class="form-control" id="nextofkin" name ="nextofkin" placeholder="e.g. Jane Doe">
        </div>
     <div class="form-group">
            <label class="text-white" for="admissionnumber">Next of Kin Address</label>
            <input type="text" class="form-control" id="nextofkinadd" name ="nextofkinadd" placeholder="e.g. P.O. Box 234 -00100- Nairobi">
        </div>
     <div class="form-group">
            <label class="text-white" for="admissionnumber">Next of Kin Mobile Phone</label>
            <input type="text" class="form-control" id="nextofkinphone" name ="nextofkinphone" placeholder="e.g. 0734567890">
        </div>
      <div class="form-group">
            <label class="text-white" for="admissionnumber">Current Occupation (if None use N/A) </label>
            <input type="text" class="form-control" id="inputAdmissionnumber" name ="cwork" placeholder="e.g. Network Administrator">
        </div>
    
      <div class="form-group">
            <label class="text-white" for="admissionnumber">Place of Current Occupation ( if None use N/A)</label>
            <input type="text" class="form-control" id="inputAdmissionnumber" name ="cplace" placeholder="e.g. Nairobi">
        </div>
    <div class="form-group">
      <label class="text-white" for="inputsupname">Supervisor Telephone Number ( if None use N/A)</label>
            <input type="text" class="form-control" name="supphone" id="supphone" placeholder="e.g. 0734567890">
    </div>
    <div class="form-group">
      <label class="text-white" for="inputsupname">Address of Current Place of Work ( if None use N/A)</label>
            <input type="text" class="form-control" name="occuadd" id="occuadd" placeholder="e.g. Rift Valley Technical Training Institute, P.O. Box 244 -30100-,Eldoret">
    </div>
        <div class="form-group">
            <label class="text-white" for="admissionnumber">Your Student Registration Number</label>
            <input type="text" class="form-control" id="inputAdmissionnumber" name ="adm" placeholder="e.g. 117R0008">
        </div>
        <div class="form-group">
    <label class="text-white" for="department">Select your Course's Department</label>
    <select class="form-control" id="dept" name="dept">
     
     <option>Automotive Engineering</option>
                        <option>Building & Civil Engineering</option>
            <option>Business and Development Studies</option>
            <option>Electrical & Electronic Engineering</option>
            <option>Hospitality & Dietetics Management</option>
                        <option>Information Communication Technology</option>
                        <option>Mechanical and Automotive Engineering</option>
            <option>Pharmacy & Chemical Science</option>
            <option>Medical & Biological Sciences</option>
                        
    </select>
    </div>
    <div class="form-group">
            <label class="text-white" for="admissionnumber">Course (in full as per registration)</label>
            <input type="text" class="form-control" id="inputcourse" name="course" placeholder="e.g. Diploma in Information Communication Technology">
        </div>
     <div class="form-group">
    <label class="text-white" for="courselevel">Select your current Course's Level</label>
    <select class="form-control" id="select" name="level">
     
     <option>Artisan</option>
                        <option>Craft</option>
            <option>Diploma</option>
            <option>Higher Diploma</option>
            
                        
    </select>
    </div>
     <div class="form-group">
       <label class="text-white" for="year"> Final Examination Year</label>
            <input type="number" class="form-control" id="datepicker" name="feyear" placeholder="e.g. 1994" min="1980" max="2018" value="2018">
     </div>
        <div class="form-group">

       <label class="text-white" for="year"> Series</label>
            <Select class="form-control" id="selectSeries" name="feser">
      <option>July</option>
            <option>November</option>
      </select>
     </div>
        <div class="form-group">
        <input type="submit" name="submit" value="Register" class="btn bg-primary btn-outline btn-xl js-scroll-trigger" ><!--<a class="btn btn-primary btnNext" >Next Tab</a> --> </div>
  </form> 
  </Select>

</div>
</div>
</section>
</main>
<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /shared/httpd/alumni/alumni/resources/views/registerStudent.blade.php ENDPATH**/ ?>