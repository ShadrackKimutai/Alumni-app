<?php $__env->startSection('title'); ?>
 <title>Generate Graduation Form</title>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container"> 
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header"><?php echo e(__('Enter Payment Details')); ?></div>

        <div class="card-body">


          
<br />

  
      <form method="post" action="<?php echo e(route('alumnis.update', $alumni->id)); ?>">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>
      
          <input type="hidden" class="form-control" name="fullname" value="<?php echo e($alumni->fullname); ?>"  />
     
          <input type="hidden" class="form-control" name="dept" value="<?php echo e($alumni->dept); ?>" />
      
          <input type="hidden" class="form-control" name="course" value="<?php echo e($alumni->course); ?>" />
       
          <input type="hidden" class="form-control" name="feser" value="<?php echo e($alumni->feser); ?>" />
        
          <input type="hidden" class="form-control" name="feyear" value="<?php echo e($alumni->feyear); ?>" />
        
          <input type="hidden" class="form-control" name="idnum" value="<?php echo e($alumni->idnum); ?>" />
       
          <input type="hidden" class="form-control" name="adm" value="<?php echo e($alumni->adm); ?>" />
       
          <input type="hidden" class="form-control" name="level" value="<?php echo e($alumni->level); ?>" />
       
          <input type="hidden" class="form-control" name="current_address" value="<?php echo e($alumni->current_address); ?>" />
      
          <input type="hidden" class="form-control" name="permanent_address" value="<?php echo e($alumni->permanent_address); ?>" />
       
          <input type="hidden" class="form-control" name="email" value="<?php echo e($alumni->email); ?>" />
        
          <input type="hidden" class="form-control" name="mobile" value="<?php echo e($alumni->mobile); ?>" />
       
          <input type="hidden" class="form-control" name="nextofkin" value="<?php echo e($alumni->nextofkin); ?>" />
       
          <input type="hidden" class="form-control" name="nextofkinphone" value="<?php echo e($alumni->nextofkinphone); ?>" />
       
          <input type="hidden" class="form-control" name="nextofkinadd" value="<?php echo e($alumni->nextofkinadd); ?>" />
      
          <input type="hidden" class="form-control" name="occupation" value="<?php echo e($alumni->occupation); ?>" />
       <input type="hidden" class="form-control" name="placeofworkadd" value="<?php echo e($alumni->placeofworkadd); ?>" />
       
          <input type="hidden" class="form-control" name="occupation_place" value="<?php echo e($alumni->occupation_place); ?>" />
      
          <input type="hidden" class="form-control" name="supervisoradd" value="<?php echo e($alumni->supervisoradd); ?>" />
       
        <div class="form-group">
          <label for="name">Payment Mode:</label>
          <select class="form-control" id="select" name="trans">

           <option>MPESA</option>
           <option>Money Order</option>
           <option>Banking Slip</option>
           <option>Other</option>


         </select>
        </div>
        <div class="form-group">
          <label for="Serial">Transaction Number:</label>
          <input type="text" class="form-control" name="serial" value="<?php echo e($alumni->Serial); ?>" />
        </div>
        
          <Button type="submit" name="previous" class="btn btn-primary">Update</Button>

      </form>
       </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /shared/httpd/alumni/alumni/resources/views/alumni/formgen.blade.php ENDPATH**/ ?>